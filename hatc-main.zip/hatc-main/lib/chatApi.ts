export interface ChatMessageInput {
  role: "user" | "assistant"
  content: string
}

function buildPrompt(messages: ChatMessageInput[]) {
  const conversation = messages
    .map((message) => {
      const label = message.role === "user" ? "User" : "Assistant"
      return `${label}: ${message.content}`
    })
    .join("\n\n")

  return `You are Hatch Coder, a fast senior software engineer AI built for production coding help.

Behavior:
- Answer the latest user message directly.
- Do not ask pointless follow-up questions when enough info exists.
- Be practical, modern, and technically accurate.
- Prefer complete working code over vague explanation.
- Keep answers concise unless the user asks for detail.
- For code, always use fenced markdown blocks with the correct language name.
- Never output raw code without triple backticks.
- When fixing bugs, explain the cause briefly, then provide the fix.
- Preserve existing project behavior unless told otherwise.

Conversation:
${conversation}`
}

export async function streamChat(
  messages: ChatMessageInput[],
  signal?: AbortSignal
): Promise<ReadableStream<Uint8Array>> {
  const apiUrl =
    process.env.HATCH_API_BASE ||
    "https://api.thehatch.store/api/chat"

  const prompt = buildPrompt(messages)

  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ prompt }),
    signal,
    cache: "no-store"
  })

  const text = await response.text()

  if (!response.ok) {
    throw new Error(
      `Hatch API Error: ${response.status} ${text || response.statusText}`
    )
  }

  let payload: any

  try {
    payload = JSON.parse(text)
  } catch {
    payload = null
  }

  const assistantResponse =
    payload?.response ||
    payload?.message ||
    payload?.text ||
    text ||
    "No response generated."

  const encoder = new TextEncoder()

  return new ReadableStream<Uint8Array>({
    start(controller) {
      controller.enqueue(encoder.encode(String(assistantResponse).trim()))
      controller.close()
    }
  })
}
