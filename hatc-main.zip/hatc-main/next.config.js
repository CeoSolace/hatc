const nextConfig = {
  reactStrictMode: true,
  images: {
    domains: ['avatars.githubusercontent.com', 'cdn.discordapp.com']
  }
}

module.exports = nextConfig
